


/**
 * FastFtp Class
 * CPSC 441 a3
 * @author asjad.malick 30002229
 * This class represents the main class as well as the sender thread
 */

//Import necessary classes
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.util.Arrays;
import java.util.Timer;

import cpsc441.a3.shared.*;

public class FastFtp {

	//The timeout interval
	private int timeout;
	
	//The transmission queue
	private TxQueue queue;
	
	//The socket by whcih to communicate with UDP protocol
	private DatagramSocket UDPConnection;
	
	//Local UDP port number
	private int UDPLocalPort;
	
	//Servers UDP port number
	private int UDPServerPort;
	
	//IP address of server
	private InetAddress IP;
	
	//A timer to measure segment timeouts
	private Timer timer;
	/**
	 * Constructor to initialize the program 
	 * 
	 * @param windowSize	Size of the window for Go-Back_N in terms of segments
	 * @param rtoTimer		The time-out interval for the retransmission timer
	 */
	public FastFtp(int windowSize, int rtoTimer) {
		
		//Initialize all instance variables
		this.timeout = rtoTimer;
		this.queue = new TxQueue(windowSize);
		try {
			this.UDPConnection = new DatagramSocket();
			this.UDPLocalPort = UDPConnection.getLocalPort();
			this.IP = InetAddress.getByName("localhost");
			this.UDPConnection.setSoTimeout(rtoTimer);
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	/**
	 * Sends the specified file to the specified destination host:
	 * 1. send file/connection infor over TCP
	 * 2. start receving thread to process coming ACKs
	 * 3. send file segment by segment
	 * 4. wait until transmit queue is empty, i.e., all segments are ACKed
	 * 5. clean up (cancel timer, interrupt receving thread, close sockets/files)
	 * 
	 * @param serverName	Name of the remote server
	 * @param serverPort	Port number of the remote server
	 * @param fileName		Name of the file to be trasferred to the rmeote server
	 */

	public void send(String serverName, int serverPort, String fileName) {
		File file = new File(fileName);
		
		//Only start protocol if file exists
		if(file.exists())
		{
			try 
			{
				//Create the TCP socket and streams
				Socket TCPConnection = new Socket(serverName, serverPort); 
				DataOutputStream TCPout = new DataOutputStream(TCPConnection.getOutputStream());
				DataInputStream TCPin = new DataInputStream(TCPConnection.getInputStream());

				//Start handshake process by sending server required info
				TCPout.writeUTF(fileName);
				TCPout.writeLong(file.length());
				TCPout.writeInt(this.UDPLocalPort);
				TCPout.flush();

				//Read response from server
				this.UDPServerPort = TCPin.readInt();

				//Get the files contents with buffered stream
				BufferedInputStream fileInput = new BufferedInputStream(new FileInputStream(file));
				byte[] buffer = new byte[Segment.MAX_PAYLOAD_SIZE];

				//Declare some variables
				int read;
				int sequenceCounter = 0;

				//Start the ack receiver thread
				ReceiverThread ackThread = new ReceiverThread(this);
				ackThread.start();

				//While loop to read through the file 1000 bytes at a time (fills the buffer)
				while( (read = fileInput.read(buffer, 0, buffer.length)) != -1)
				{
					//Create a new byte array
					byte[] payload = null;

					//if the amount of bytes read is not 1000 (last segment) then only copy up to that point
					//from the buffer into payload
					//Otherwise copy the entire buffer into payload
					if(read != Segment.MAX_PAYLOAD_SIZE)
						payload = Arrays.copyOf(buffer, read);
					else
						payload = Arrays.copyOf(buffer, buffer.length);

					//Create the segment
					Segment seg = new Segment(sequenceCounter, payload);

					while(queue.isFull())
					{
						//Wait
					}
					//Send the segment
					this.processSend(seg);
					sequenceCounter++;
				}

				//End of file reached
				
				while(!queue.isEmpty())
				{
					//Wait for queue to be empty
				}

				//Cancel timer
				this.timer.cancel();
				
				//kill receiver thread
				ackThread.kill();
				
				//Close all IO streams
				fileInput.close();
				TCPConnection.close();
				UDPConnection.close();
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		}
		else
		{
			System.out.println("Provided File does not exist");
		}
	}

	/**
	 * method to be called when needing to send a segment
	 * @param seg The segment to send
	 */
	public synchronized void processSend(Segment seg) {

		//Create the datagram packet
		byte[] data = seg.getBytes();
		DatagramPacket pkt = new DatagramPacket(data, data.length, this.IP, this.UDPServerPort);

		try 
		{
			//Send the packet over the connection and add segment to queue
			this.UDPConnection.send(pkt);
			this.queue.add(seg);

			//If it is the first segment in the queue then schedule a timeout
			if(this.queue.size() == 1)
			{
				this.timer = new Timer(true);
				timer.schedule(new TimeoutHandler(this), this.timeout);
			}
		} 
		catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}

	}

	/**
	 * method to be called when an ack needs to be processed
	 * @param seg The segment received from server
	 */
	public synchronized void processACK(Segment ack) {

		//Get the ack sequence number
		int headAck = this.queue.element().getSeqNum();
		int incomingAck = ack.getSeqNum();

		//If the incoming ack is able to purge anything from transmission queue
		if(incomingAck > headAck)
		{
			//cancel timer
			this.timer.cancel();
			try {
				//remove the head packet from the queue
				this.queue.remove();
				boolean run = true;

				//While there are still elements to remove
				while(run)
				{
					//if nothing left, end loop
					if(!this.queue.isEmpty())
					{
						//get the next ack, if it can be removed do so, otherwise end the loop
						int qAck = this.queue.element().getSeqNum();

						if(qAck < incomingAck)
							this.queue.remove();
						else
							run = false;
					}
					else
					{
						//End loop
						run = false;
					}
					
				}
				
				//If there are still elements then start the timer
				if(!this.queue.isEmpty())
				{
					this.timer = new Timer(true);
					timer.schedule(new TimeoutHandler(this), this.timeout);
				}

			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
	
	/**
	 * Method to be called when a timeout occurs
	 */
	public synchronized void processTimeout() {
		
		//Get all the pending segments
		Segment[] segmentArray = this.queue.toArray();

		//Send all the segments in the array
		for(Segment s : segmentArray)
		{
			byte[] data = s.getBytes();
			DatagramPacket pkt = new DatagramPacket(data, data.length, this.IP, this.UDPServerPort);
			try 
			{
				this.UDPConnection.send(pkt);
			} catch (IOException e) {
				// Print any errors if they occur
				e.printStackTrace();
			}
		}
		
		//Cancel the current timer, make a new one and schedule it again
		this.timer.cancel();
		this.timer = new Timer(true);
		timer.schedule(new TimeoutHandler(this), this.timeout);
	}

	/**
	 * Method to give access to the UDP socket to other threads and classes
	 * @return the UDP socket
	 */
	public DatagramSocket UDPConnection()
	{
		return this.UDPConnection;
	}

	/**
	 * A simple test driver
	 * 
	 */
	public static void main(String[] args) {
		// all srguments should be provided
		// as described in the assignment description 
		if (args.length != 5) {
			System.out.println("incorrect usage, try again.");
			System.out.println("usage: FastFtp server port file window timeout");
			System.exit(1);
		}

		// parse the command line arguments
		// assume no errors
		String serverName = args[0];
		int serverPort = Integer.parseInt(args[1]);
		String fileName = args[2];
		int windowSize = Integer.parseInt(args[3]);
		int timeout = Integer.parseInt(args[4]);

		// send the file to server
		FastFtp ftp = new FastFtp(windowSize, timeout);
		System.out.printf("sending file \'%s\' to server...\n", fileName);
		ftp.send(serverName, serverPort, fileName);
		System.out.println("file transfer completed.");
	}
}
