

/**
 * ReceiverThread class
 * CPSC 441 A3
 * @author asjad.malick 30002229
 * This class will handle the incoming ack responses from the server
 */

//Import necessary classes
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.SocketException;
import java.net.SocketTimeoutException;

import cpsc441.a3.shared.*;

public class ReceiverThread extends Thread
{
	//The Fastftp client (Sender thread)
	private FastFtp client;
	
	//Boolean to see if thread needs to die
	private boolean keepRunning = true;
	
	/**
	 * Constructor
	 * @param f - the FastFtp that runs the receiver thread
	 */
	public ReceiverThread (FastFtp f)
	{
		//Initialze client
		client = f;
	}
	
	@Override
	public void run()
	{
		while(keepRunning)
		{
			
			//Create a byte array to receive the ack
			byte[] inPacketArray = new byte[Segment.MAX_SEGMENT_SIZE];
			DatagramPacket inPacket = new DatagramPacket(inPacketArray, inPacketArray.length);
			try {
				
				//If the connection is closed don't try to send
				if(!client.UDPConnection().isClosed())
				{
					//Receive the packet
					client.UDPConnection().receive(inPacket);
					Segment seg = new Segment(inPacketArray);
					
					// Call the process ack method in the client
					client.processACK(seg);
				}
			}
			catch(SocketTimeoutException e2){
				//If this exception is thrown nothing was read
				//No action needs to be taken so it is safe to ignore this exception
				//It allows the loop to check if a kill command was received
			}
			catch(SocketException e3)
			{
				//This only will occur if thread calls the receive method after socket has closed
				//Only response should be ensuring the thread dies
				keepRunning = false;
			}
			catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * Method to kill the thread, set the boolean to be false
	 */
	public void kill()
	{
		keepRunning = false;
	}
}
