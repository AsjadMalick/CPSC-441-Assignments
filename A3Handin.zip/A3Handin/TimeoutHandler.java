
/**
 * CPSC 441 A3
 * @author asjad.malick
 * This class will handle timeouts
 */

//Import class
import java.util.TimerTask;

public class TimeoutHandler extends TimerTask 
{
	//The client that generates the timer
	FastFtp client;
	
	/**
	 * The constructor for the class
	 * @param f - The FastFtp client that generates the timer
	 */
	public TimeoutHandler(FastFtp f)
	{
		client = f;
	}
	@Override
	public void run() 
	{
		//Call the timeout method in the client
		client.processTimeout();
	}
}
