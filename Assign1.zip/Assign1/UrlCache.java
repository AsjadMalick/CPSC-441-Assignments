
/**
 * @author Asjad Malick
 * 30002229
 * CPSC 441 A1
 */

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.TimeZone;

public class UrlCache {

	//The hashMap for the catalog
	private HashMap<String, String> catalog = new HashMap<String, String>();

	//The date format to convert dates with
	private SimpleDateFormat ft = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz");

	/**
	 * Default constructor to initialize data structures used for caching/etc
	 * If the cache already exists then load it. If any errors then throw runtime exception.
	 * @throws IOException if encounters any errors/exceptions
	 */
	public UrlCache() throws IOException 
	{
		//The locally created cache file
		File f = new File("clientCache.txt");

		//Set the timezone to default to GMT
		ft.setTimeZone(TimeZone.getTimeZone("GMT"));

		if(f.exists())
		{
			//Load existing catalog
			Scanner sc = new Scanner(f);
			while(sc.hasNextLine())
			{
				//Using two tabs to delimit 
				String x[] = sc.nextLine().split("\t\t");
				if(x.length > 1)
					catalog.put(x[0], x[1]);
			}
			sc.close();
		}
		else
		{
			//create new file
			PrintWriter pw = new PrintWriter(new FileWriter(new File("clientCache.txt")));
			pw.close();
		}
	}

	/**
	 * Downloads the object specified by the parameter url if the local copy is out of date.
	 * @param url	URL of the object to be downloaded. It is a fully qualified URL.
	 * @throws IOException if encounters any errors/exceptions
	 */
	public void getObject(String url) throws IOException 
	{
		//Get the individual sections
		String urlSections[] = url.split("/");
		String portString = "80";
		String hostString = urlSections[0];

		//handling if port number is specified
		if(urlSections[0].contains(":"))
		{
			String hostSections[] = urlSections[0].split(":");
			portString = hostSections[1];
			hostString = hostSections[0];
		}

		//Save port number as integer
		int port = Integer.parseInt(portString);

		//Open socket
		Socket socket = new Socket(hostString, port);

		//Setup of IO streams
		InputStream inputStream = socket.getInputStream(); //Allow bytes
		PrintWriter outputStream = new PrintWriter(socket.getOutputStream());

		//Obtain the pathname by concatenating different sections
		String pathName = "";

		//The lists to store the responses of server
		//The list to store the bytes read from server response
		ArrayList<Byte> dataIn = new ArrayList<Byte>();
		
		//List to store bytes as strings to make parsing to certain lines easier
		ArrayList<String> stringData = new ArrayList<String>();

		//Loop to concatenate the sections of the URL
		for(int i = 1; i < urlSections.length; i++)
		{
			//If on the last iteration do not add a / otherwise, add a /
			if(i == urlSections.length - 1)
				pathName = pathName + urlSections[i];
			else
				pathName = pathName + urlSections[i] + "/";
		}

		//Indices to show the location of certain lines in arrayList
		//For the line with the last modified statement
		int lastModIndex = 0;

		//Index to find end of header/beginning of body in byte arrayList
		int byteBlankIndex = 0;

		try
		{
			//Get last modified date
			long lastMod = getLastModified(url);
			Date d = new Date(lastMod);

			//Construct the get request
			outputStream.print("GET "+ "/" + pathName + " HTTP/1.1\r\n");
			outputStream.print("If-Modified-Since: " + ft.format(d)+ "\r\n");
			outputStream.print("Host: " + hostString+"\r\n");
			outputStream.print("\r\n");
			outputStream.flush();

			//Booleans to prevent duplicates, only need first occurrences of key strings
			boolean blankDetected = false;
			boolean lastModDetected = false;

			//Keep track of current string line index
			int count = 0;
			
			//Keep track of number of bytes parsed
			int byteCount = 0;

			//While loop to read response
			
			//String buffer to store line 
			//(using String as a String buffer since its easier to use)
			String buff = "";
			
			//Int to read IO stream response
			int t;
			while ( (t = inputStream.read()) != -1)
			{
				//Convert the int into a byte
				byte b = (byte)t;
				
				//Store byte in data Array
				dataIn.add(b);
				
				
				//Add the byte to string buffer by converting to character
				char x = (char) b;
				buff = buff + x;

				//If the character is a newLine, 
				//it is end of line so add to arrayList for strings
				if(x == '\n')
				{
					//Add buffer
					stringData.add(buff);

					//If the buffer EQUALS carriage return, then we in the blank
					//between header and body, or not if blankDetected is already true
					if(buff.equals("\r\n") && !blankDetected)
					{
						//Set boolean to true (prevent triggers on multiple blank lines)
						// It should only trigger on first one (before body)
						blankDetected = true;
						
						//Go past the next carraige return thats coming so byte array
						//knows where to start to read body
						byteBlankIndex = byteCount + 1;
					}

					//For the last modified line
					
					//The boolean check is to prevent a case where multiple lines contain last mod
					//So only the first case will enter the loop (in the header)
					//Checks the buffer to see if this is the line for the last modified info 
					if(buff.contains("Last-Modified:") && !lastModDetected)
					{
						//Set boolean to true
						lastModDetected = true;
						
						//Save index to STRING array knows where to look
						lastModIndex = count;
					}

					// 'flush' the buffer
					buff = "";
					//Increase count for STRING count
					count++;
				}
				//Increment BYTE count
				byteCount++;
			}

		}
		catch(RuntimeException rte)
		{
			//If an exception is thrown, do a normal GET request w/o condition
			//Same as shown in the try section
			//Exception will most likely from the getLastModified Method
			outputStream.print("GET "+ "/" + pathName + " HTTP/1.1\r\n");
			outputStream.print("Host: " + hostString+"\r\n");
			outputStream.print("\r\n");
			outputStream.flush();


			//Booleans to prevent duplicates, only need first occurrences of key strings
			boolean blankDetected = false;
			boolean lastModDetected = false;

			//Keep track of current string line index
			int count = 0;
			
			//Keep track of number of bytes parsed
			int byteCount = 0;

			//While loop to read response
			
			//String buffer to store line 
			//(using String as a String buffer since its easier to use)
			String buff = "";
			
			//Int to read IO stream response
			int t;
			while ( (t = inputStream.read()) != -1)
			{
				//Convert the int into a byte
				byte b = (byte)t;
				
				//Store byte in data Array
				dataIn.add(b);
				
				
				//Add the byte to string buffer by converting to character
				char x = (char) b;
				buff = buff + x;

				//If the character is a newLine, 
				//it is end of line so add to arrayList for strings
				if(x == '\n')
				{
					//Add buffer
					stringData.add(buff);

					//If the buffer EQUALS carriage return, then we in the blank
					//between header and body, or not if blankDetected is already true
					if(buff.equals("\r\n") && !blankDetected)
					{
						//Set boolean to true (prevent triggers on multiple blank lines)
						// It should only trigger on first one (before body)
						blankDetected = true;
						
						//Go past the next carraige return thats coming so byte array
						//knows where to start to read body
						byteBlankIndex = byteCount + 1;
					}

					//For the last modified line
					
					//The boolean check is to prevent a case where multiple lines contain last mod
					//So only the first case will enter the loop (in the header)
					//Checks the buffer to see if this is the line for the last modified info 
					if(buff.contains("Last-Modified:") && !lastModDetected)
					{
						//Set boolean to true
						lastModDetected = true;
						
						//Save index to STRING array knows where to look
						lastModIndex = count;
					}

					// 'flush' the buffer
					buff = "";
					//Increase count for STRING count
					count++;
				}
				//Increment BYTE count
				byteCount++;
			}
		}

		//The file has not been modified since the date, inform user
		if(stringData.get(0).contains("304"))
		{
			System.out.print(stringData.get(0));
			System.out.println(hostString + "/" + pathName + " is already in local directory\nand is up to date");
		}

		//Modification/Update required
		else if(stringData.get(0).contains("200"))
		{
			//Let user know HTTP is going through
			System.out.println(stringData.get(0));
			
			//Create the key for the Hashmap catalog
			String catalogKey = hostString+ "/" + pathName;

			//Get the directory sequence to make
			String directoryPath = catalogKey.substring(0, catalogKey.lastIndexOf("/") + 1);

			//Make the directory sequence if possible, ignore the boolean value that results
			boolean ignoreThisBooleanVal = new File(directoryPath).mkdirs();

			//Create the fileOutputStream to allow for writing of Byte data
			FileOutputStream output = new FileOutputStream(new File(catalogKey), true);
			
			//Loop through the byte array from the index earlier and write the bytes to a file
			for(int i = byteBlankIndex; i < dataIn.size(); i++) 
				output.write(dataIn.get(i));  //Write the data
			
			//Close the stream
			output.close();

			//Get last modified date from response header
			String lastMod = stringData.get(lastModIndex).split(": ")[1];

			//Update the catalog (or create new entry)
			catalog.put(catalogKey, lastMod);

			//Boolean to check if file is in Cache already
			boolean exists = false;
			
			//Get the cache's contents
			File cache = new File("clientCache.txt");
			List<String> fileContent = new ArrayList<String>(Files.readAllLines(cache.toPath(), StandardCharsets.UTF_8));

			//Find entry in catalog if it exists, and replace it with updated version
			for(int i = 0; i < fileContent.size(); i++)
			{
				//Get line from arrayList
				String line = fileContent.get(i);
				if(line.split("\t\t")[0].equals(catalogKey))
				{
					//Update the entry and set boolean true
					fileContent.set(i, catalogKey + "\t\t" + lastMod);
					exists = true;
				}
			}

			//If entry does not exists already in master file, add it
			if(!exists)
				fileContent.add(catalogKey + "\t\t" + lastMod);

			//Update file with the modified ArrayList
			Files.write(cache.toPath(), fileContent, StandardCharsets.UTF_8);
		}

		//close the ALL the open streams
		inputStream.close();
		outputStream.close();
		socket.close();
	}

	/**
	 * Returns the Last-Modified time associated with the object specified by the parameter url.
	 * @param url 	URL of the object 
	 * @return the Last-Modified time in millisecond as in Date.getTime()
	 * @throws RuntimeException if catalog is empty for url key
	 */
	public long getLastModified(String url) throws RuntimeException
	{
		long millis = 0;

		//Get the sections of the URL to ignore the port number if specified in the URL
		//Code is very similar as to what has been demonstrated in getObject method
		String urlSections[] = url.split("/");
		String hostString = urlSections[0];

		if(urlSections[0].contains(":"))
		{
			String hostSections[] = urlSections[0].split(":");
			hostString = hostSections[0];
		}

		String pathName = "";
		for(int i = 1; i < urlSections.length; i++)
		{
			if(i == urlSections.length - 1)
				pathName = pathName + urlSections[i];
			else
				pathName = pathName + urlSections[i] + "/";
		}

		//See if key exists in the first place
		if(catalog.containsKey(hostString + "/" + pathName))
		{
			//Get value of the key
			String lastModString = catalog.get(hostString + "/" + pathName);

			if(lastModString == null)
			{
				//Throw exception if the value does not exists for the key
				throw new RuntimeException();
			}

			//Convert the string into a date in GMT time
			Date date = ft.parse(lastModString, new ParsePosition(0));

			//Return the date converted to milliseconds
			millis = date.getTime();
		}
		else
		{
			//If key doesn't exist throw runtime exception
			throw new RuntimeException();
		}
		//Return result
		return millis;
	}


	public static void main(String[] args) 
	{
		// include whatever URL you like
		// these are just some samples

		String[] url = { "localHost:2225/a.txt"};
		// this is a very basic tester
		// the TAs will use a more comprehensive set of tests
		try {
			UrlCache cache = new UrlCache();

			cache.getObject(url[0]);
			//cache.getObject(url[1]);
			//cache.getObject(url[2]);
			//cache.getObject(url[3]);

			//for (int i = 0; i < url.length; i++)
			//cache.getObject(url[i]);

			//System.out.println("Last-Modified for " + url[0] + " is: " + cache.getLastModified(url[0]));
			//cache.getObject(url[0]);
			//System.out.println("Last-Modified for " + url[0] + " is: " + cache.getLastModified(url[0]));
		} catch (IOException e) 
		{
			System.out.println("There was a problem: " + e.getMessage());
			e.printStackTrace();
		}

	}
}
