
/**
* RequestParser Class
* Handles GET requests made to the server
* @author Asjad Hassan Malick
* 30002229
* CPSC 441 Assignment 2
*/

//import required classes
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.TimeZone;

public class RequestParser implements Runnable
{
	//The socket to use to communicate with client
	private Socket Connection;
	
	//The input stream to read socket input
	private Scanner input;
	
	//Output stream to respond to client over socket
	private OutputStream response;
	
	//Hostname
	private String hostName = "";
	
	//Format for printing last modified date
	private SimpleDateFormat ft = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz");
	
	
	/**
	 * The default constructor for RequestParser
	 * @param s - Socket to communicate with client
	 * @param name - the server hostname
	 * @throws IOException
	 */
	public RequestParser(Socket s, String name) throws IOException
	{
		//Instantiate all instance variables
		this.Connection = s;
		hostName = name;
		input = new Scanner(s.getInputStream());
		response = s.getOutputStream();
		ft.setTimeZone(TimeZone.getTimeZone("GMT"));
	}
	
	/**
	 * The run method, returns nothing but handles request
	 */
	public void run()
	{
		try
		{
			//Grab first line of request from client (ignore rest, only care for basic GET)
			String lineInput = input.nextLine();
			
			//Grabled mess before the GET
			if(!Character.isLetter(lineInput.charAt(0)))
			{
				//Was suggested by TA That I split at "GET "
				String[] inputLine = lineInput.split("GET ", 2);
				
				//Check if response is malformed
				if(inputLine.length != 2)
					this.response400();
				
				else
				{
					//Get the components of the request
					String requestLine[] = inputLine[1].split("\\s+");
					
					//Check if request is malformed
					if(requestLine.length != 2 || !requestLine[1].contains("HTTP/"))
						this.response400();
					
					else
					{
						if(requestLine[0].charAt(0) != '/')
						{
							// Check if Request is malformed
							this.response400();
						}
						else
						{
							//Request is not malformed
							File f = new File(requestLine[0].substring(1));
							
							//If the file exists then give  response 200, otherwise 404
							if(f.exists())
								this.response200(f);
							
							else
								this.response404();
						}
						
					}
				}
			}
			
			//No garbled mess before requestLine
			else
			{
				String[] inputLine = lineInput.split(" ");
				
                                //Check if all components are there, if not return 400
				if(inputLine.length != 3 )
					this.response400();
				else
				{
                                        //Check again for malformed request
					if(!inputLine[0].equals("GET") || !inputLine[2].contains("HTTP/"))
						this.response400();
						
					else
					{
						if(inputLine[1].charAt(0) != '/')
						{
							// Check if Request is malformed
							this.response400();
						}
						else
						{
							//Request is not malformed
							File f = new File(inputLine[1].substring(1));
							//If the file exists then give  response 200, otherwise 404
							if(f.exists())
								this.response200(f);
							
							else
								this.response404();
						}
					}
				}
			}
			
			
			
		} 
		catch(Exception e)
		{
			//If any errors occurred, assume malformed response
			this.response400();
		}
		finally
		{
			//No matter what happens close ALL streams before exiting run method
			try
			{
				this.input.close();
				this.response.close();
				this.Connection.close();
			}
			catch(IOException e)
			{
				System.out.println("Error while closing connection");
			}
			
		}
	}
	
	/**
	 * This method writes a response 200 to the socket
	 * @param f the file to give back
	 */
	private void response200(File f)
	{
		try
		{
			//Start creating the lines individually
			String firstLine = "HTTP/1.1 200 OK\r\n";
			
			//Get the current date and format it
			Date d = new Date();
			String dateLine = "Date: " + ft.format(d) + "\r\n";
			
			//Server name
			String serverLine = "Server: " + hostName + "\r\n";
			
			//The last modified date of the file formatted
			String lastMod = "Last-Modified: " + 
			ft.format( new Date(f.lastModified()) ) + "\r\n";
			
			//Content length
			String length = "Content-Length: " + f.length() + "\r\n";
			
			//Content type
			String type = "Content-Type: " + Files.probeContentType(f.toPath()) + "\r\n";
			
			//Close connection line
			String connectLine = "Connection: close\r\n\r\n";
			
			//Concatenate all the strings into 1
			String header = firstLine + dateLine + serverLine 
					+ lastMod +length + type + connectLine;
			
			//Convert the header into bytes
			byte[] headerBytes = header.getBytes();
			
			//Get the bytes from the file
			FileInputStream is = new FileInputStream(f);
			byte[] payloadBytes = new byte[is.available()];
			is.read(payloadBytes);
			
			//Close the file stream
			is.close();
			
			//Write the bytes to the socket
			response.write(headerBytes);
			response.write(payloadBytes);
			response.flush();
		}
		catch(IOException e)
		{
			//Print if any error occurs
			System.out.println("Error while sending response");
		}
		
	}
	
	/**
	 * This method writes a 400 response if request is malformed
	 */
	private void response400()
	{
		//Create the individual lines to print Very similar to 200 response method
		String firstLine = "HTTP/1.1 400 Bad Request\r\n";
		Date d = new Date();
		String dateLine = "Date: " + ft.format(d) + "\r\n";
		String serverLine = "Server: " + hostName + "\r\n";
		String connectLine = "Connection: close\r\n\r\n";
		
		//Concatenate the line into 1 string
		String msg = firstLine + dateLine + serverLine + connectLine;
		
		//get the bytes of the string
		byte[] msgBytes = msg.getBytes();
		
		try 
		{
			//write the bytes onto the socket
			response.write(msgBytes);
			response.flush();
		} 
		catch (IOException e) 
		{
			//Print if any error occurs
			System.out.println("Error while sending response");
		}
		
	}
	
	/**
	 * This method writes a 404 response if file could not be found
	 */
	private void response404()
	{
		//Similar to other response method, create the individual lines for message
		String firstLine = "HTTP/1.1 404 Not Found\r\n";
		Date d = new Date();
		String dateLine = "Date: " + ft.format(d) + "\r\n";
		String serverLine = "Server: " + hostName + "\r\n";
		String connectLine = "Connection: close\r\n\r\n";
		
		//Concatenate message
		String msg = firstLine + dateLine + serverLine + connectLine;
		
		//Get message Bytes
		byte[] msgBytes = msg.getBytes();
		
		try 
		{
			//Write message to socket 
			response.write(msgBytes);
			response.flush();
		} 
		catch (IOException e) 
		{
			//Print if error occurs
			System.out.println("Error while sending response");
		}
	}
}
