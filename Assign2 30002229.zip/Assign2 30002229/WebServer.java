
/**
 * WebServer Class
 * Creates a web server that listenes for GET requests
 * @author Asjad Hassan Malick
 * 30002229
 * CPSC 441 Assignment 2
 */

//Import required classes
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;

public class WebServer extends Thread {

	//The main server socket
	private ServerSocket serverSocket;
	
	// Port number defaulted to 2225
	private int portNum = 2225;
	
	//Flag to keep run while loop going
	private boolean flag;
	
	/**
	 * Default constructor to initialize the web server 
	 * @param port 	The server port at which the web server listens > 1024
	 */
	public WebServer(int port) {

		try 
		{
			//If the port number is in correct range setup otherwise throw an exception
			if(port > 1024 && port < 65536)
			{
				portNum = port;
				flag = true;
			}
			else
				throw new IOException();


		} catch (IOException e) 
		{
			//Print error message if any exception is thrown
			System.out.println(e);
			System.out.println("Socket port not valid.");
		}
	}

	/**
	 * The main loop of the web server
	 * Opens a server socket at the specified server port
	 * Remains in listening mode until shutdown signal
	 * 
	 */
	public void run() {
		
		//Create the threadpool
		ExecutorService executor = Executors.newFixedThreadPool(8);
		try
		{
			//Instantiate the server socket
			this.serverSocket = new ServerSocket(this.portNum);
			
			//Set timeout to remove block from accept() method
			this.serverSocket.setSoTimeout(1000);
			
			//Get hostname of socket
			String name = this.serverSocket.getInetAddress().getHostName();
			
			//Keep running until flag is false
			while(flag)
			{
				try
				{
					//Accept incoming request for connection
					Socket s = this.serverSocket.accept();
					
					//Create a worker instance
					Runnable connection = new RequestParser(s, name);
					
					//Execute the worker
					executor.execute(connection);
				} 
				catch(SocketTimeoutException e1){/* Ignore this exception*/} 
				catch (IOException e)
				{
					//Print if any error occurred
					e.printStackTrace();
				}
				
			}

			//Begin shutdown
			executor.shutdown();
			
			// wait 5 seconds for existing tasks to terminate
			if (!executor.awaitTermination(5, TimeUnit.SECONDS)) 
				// cancel currently executing tasks
				executor.shutdownNow();
			
			//close socket
			this.serverSocket.close();
		} 
		catch (InterruptedException e) 
		{
			executor.shutdownNow();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}


	/**
	 * Signals the server to shutdown.
	 * set flag to false
	 */
	public void shutdown() {
		flag = false;
	}

	/**
	 * A simple driver.
	 */

	public static void main(String[] args) {

		int serverPort = 2225;
		// parse command line args

		if (args.length == 1) {
			serverPort = Integer.parseInt(args[0]);
		}

		if (args.length >= 2) {
			System.out.println("wrong number of arguments");
			System.out.println("usage: WebServer <port>");
			System.exit(0);
		}

		System.out.println("starting the server on port " + serverPort);
		WebServer server = new WebServer(serverPort);
		server.start();
		System.out.println("server started. Type \"quit\" to stop");
		System.out.println(".....................................");

		Scanner keyboard = new Scanner(System.in);
		while ( !keyboard.next().equals("quit") );

		keyboard.close();
		System.out.println();
		System.out.println("shutting down the server...");
		server.shutdown();
		System.out.println("server stopped");
	}
}


