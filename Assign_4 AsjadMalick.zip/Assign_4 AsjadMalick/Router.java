
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Timer;

import cpsc441.a4.shared.*;

/**
 * Router Class
 * CPSC 441 A4 
 * @author 	Asjad Malick
 * 30002229
 * 
 * This class implements the functionality of a router
 * when running the distance vector routing algorithm.
 * 
 * The operation of the router is as follows:
 * 1. send/receive HELLO message
 * 2. while (!QUIT)
 *      receive ROUTE messages
 *      update mincost/nexthop/etc
 * 3. Cleanup and return
 *
 */
public class Router {

	//The socket used for the server connection
	private Socket TCPConnection;
	
	//Input output streams for the socket
	private ObjectOutputStream out;
	private ObjectInputStream in;
	
	//variables to instantiate router instance wih
	//name of the server
	private String servName;
	
	//port number of the server
	private int servPort;
	
	//Timeout interval
	private int timeOut;
	
	//Router id
	private int ID;

	//The array to store the cost to go to other routers
	private int[] linkCost;
	
	//A 2d array which contains the minimum dV of this router at mincost[ID]
	private int[][] minCost;
	
	//An array showing which router to go to next for a path through the topology.
	private int[] nextHop;

	//Number of nodes in the network
	private int nodes;

	//ArrayList to store the ids of the neighbors of this router
	private ArrayList<Integer> neighbors = new ArrayList<Integer>();

	//The timer to handle timeout
	private Timer timer;

	/**
	 * Constructor to initialize the rouer instance 
	 * 
	 * @param routerId			Unique ID of the router starting at 0
	 * @param serverName		Name of the host running the network server
	 * @param serverPort		TCP port number of the network server
	 * @param updateInterval	Time interval for sending routing updates to neighboring routers (in milli-seconds)
	 */
	public Router(int routerId, String serverName, int serverPort, int updateInterval) {
		
		//Initialize variables
		this.ID = routerId;
		this.servName = serverName;
		this.servPort = serverPort;
		this.timeOut = updateInterval;
	}

	
	/**
	 * Method to send an array to all of this routers neighbors
	 * @param toSend - an int array that must be sent
	 * @throws IOException - in case any error occurs throw it
	 */
	private void sendAll(int[] toSend) throws IOException
	{
		//For every neighbor, create a dvr packet of toSend and send it.
		for(int i : this.neighbors)
		{
			DvrPacket sendLink = new DvrPacket(this.ID, i, DvrPacket.ROUTE, toSend);
			this.out.writeObject(sendLink);
		}
	}
	
	/**
	 * Method that uses the bellman-Ford algorithm to calculate the minimum cost vector
	 * for this router.
	 * @return the mincost array calculated
	 */
	public int[] getMinVector()
	{
		//The array that will be returned
		int[] minVector = new int[this.nodes];
		
		//For every index in the minimum distance vector
		for(int destinationIndex = 0; destinationIndex < this.nodes; destinationIndex++)
		{
			//Skip if the routers index has come up. Answer is always 0
			if(destinationIndex != this.ID)
			{
				//Create a Hashmap to allow for nextHop determiantion
				HashMap<Integer, Integer> minimumHop = new HashMap<Integer, Integer>();
				
				//List to store all the possible costs to a destination
				ArrayList<Integer> costs = new ArrayList<Integer>();
				
				//Only go through the neighbors
				for(int nIndex : this.neighbors)
				{
					//Get cost as specified in bellman ford
					// D_(a,b) = Link(a,c) + D(c,b) where a,b,c are router Ids
					int cost = this.linkCost[nIndex] + 
							this.minCost[nIndex][destinationIndex];
					
					//Add the cost to the arrayList
					costs.add(cost);
					
					//Use the cost as a key to the index which results in this cost
					minimumHop.put(cost, nIndex);
				}

				//get the minimum value of all hte costs
				int minimum = Collections.min(costs);
				
				//Get the value associated with the cost key from the hashmap
				int hopVal = minimumHop.get(minimum);
				
				// Store the value in the next hop array
				this.nextHop[destinationIndex] = hopVal;
				
				//Store the minimum value in the appropriate index for minVector
				minVector[destinationIndex] = minimum;
			}
		}

		//Return minVector
		return minVector;
	}

	/**
	 * starts the router 
	 * 
	 * @return The forwarding table of the router
	 */
	public RtnTable start() {

		try 
		{
			//Create the connection to the server, and initialize streams
			this.TCPConnection = new Socket(this.servName, this.servPort);
			this.in = new ObjectInputStream(this.TCPConnection.getInputStream());
			this.out = new ObjectOutputStream(this.TCPConnection.getOutputStream());

			//Create the first hello packet to recive link cost info from server
			DvrPacket helloPacket = new DvrPacket(this.ID, DvrPacket.SERVER, DvrPacket.HELLO);
			this.out.writeObject(helloPacket);

			//Recive the hello response
			DvrPacket helloResponse = (DvrPacket) this.in.readObject();

			//Instantiate the arrays
			this.linkCost = helloResponse.mincost.clone();
			this.nodes = this.linkCost.length;
			this.minCost = new int[this.nodes][this.nodes];
			this.nextHop = new int[this.nodes];
			
			//The next hop to go to the router itself is its own ID
			this.nextHop[this.ID] = this.ID;

			//Set the routers min cost equal to its link cost
			this.minCost[this.ID] = this.linkCost.clone();

			//For loop that finds the neighbors of the router and adds it to list
			for(int i = 0; i < this.linkCost.length; i++)
				if( (this.linkCost[i] != DvrPacket.INFINITY) && (this.linkCost[i] != 0))
					this.neighbors.add(i);

			//Send all the neighbors this routers current mincost vector
			this.sendAll(this.minCost[this.ID].clone());

			//Start the timer
			this.timer = new Timer(true);
			this.timer.schedule(new TimeoutHandler(this), this.timeOut);

			//Boolean to control the loop
			boolean quit = false;
			
			while(!quit)
			{
				//Receive the incoming packet
				DvrPacket incoming = (DvrPacket) this.in.readObject();
				
				//IF the incoming packet is a quit, then change control variable
				//Otherwise call process DVR
				if(incoming.type == DvrPacket.QUIT)
					quit = true;
				else
					this.processDvr(incoming);
			}

			//Close the input Streams and socket
			//Also cancel the timer
			this.in.close();
			this.out.close();
			this.TCPConnection.close();
			this.timer.cancel();
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		} catch (ClassNotFoundException e) 
		{	
			e.printStackTrace();
		}

		//Get the table to be returned and return it.
		RtnTable table = new RtnTable(this.minCost[this.ID], this.nextHop);
		return table;
	}

	/**
	 * Method to process the dvr packets received 
	 * @param dvr the DvrPacket received 
	 */
	public void processDvr (DvrPacket dvr) 
	{
		//Since the packet was not a quit, if it came from server 
		//It is a link cost change
		if(dvr.sourceid == DvrPacket.SERVER)
		{
			//Set the link cost to whatever the packet contains
			this.linkCost = dvr.mincost.clone();
			
			//Clear the neighbors list (it has changed)
			this.neighbors.clear();
			
			//Add the neighbors again with a very similar loop as before
			for(int i = 0; i < this.linkCost.length; i++)
				if( (this.linkCost[i] != DvrPacket.INFINITY) && (this.linkCost[i] != 0))
					this.neighbors.add(i);
			
			//Recalculate the mincost vector for the router
			int[] postMinCost = this.getMinVector();

			//Print out the link cost vector received
			System.out.print("Link cost changed to: " + "[");
			for(int i = 0; i < this.linkCost.length; i++)
			{
				if(i == this.linkCost.length - 1)
					System.out.print(this.linkCost[i]);
				else
					System.out.print(this.linkCost[i] + ", ");
			}
			System.out.print("]\n");
			
			//If the minimum cost vector calculated is different from the current one
			if(!Arrays.equals(postMinCost, this.minCost[this.ID]))
			{
				//Update what is stored in the 2d array
				//Cancel the timer
				this.minCost[this.ID] = postMinCost.clone();
				this.timer.cancel();
				try
				{
					//Send the new min vector to all neighbors
					this.sendAll(postMinCost);

					//Print out the Dv that was sent
					System.out.print("Sending DV to neighbors: " + "[");
					for(int i = 0; i < this.minCost[this.ID].length; i++)
					{
						if(i == this.minCost[this.ID].length - 1)
							System.out.print(this.minCost[this.ID][i]);
						else
							System.out.print(this.minCost[this.ID][i] + ", ");
						
					}
					System.out.print("]\n");
				}
				catch(IOException e)
				{
					e.printStackTrace();
				}
				
				//Reset the timer
				this.timer = new Timer(true);
				this.timer.schedule(new TimeoutHandler(this), this.timeOut);
			}
		}
		else
		{
			//The else means that a router is sending its min vector
			
			//Grab the mincost vector and store it in the senders row in the 2d array
			this.minCost[dvr.sourceid] = dvr.mincost.clone();
			
			//Calculate this routers mincost vector
			int[] postMinCost = this.getMinVector();

			//If this routers mincost vector has chnaged then go into the if
			if(!Arrays.equals(postMinCost, this.minCost[this.ID]))
			{
				//Update what is stored in the 2d array
				//Cancel the timer
				this.minCost[this.ID] = postMinCost.clone();
				this.timer.cancel();
				try
				{
					//Send the new min vector to all neighbors
					this.sendAll(postMinCost);
					
					//Print out the Dv that was sent
					System.out.print("Sending DV to neighbors: " + "[");
					for(int i = 0; i < this.minCost[this.ID].length; i++)
					{
						
						if(i == this.minCost[this.ID].length - 1)
							System.out.print(this.minCost[this.ID][i]);
						else
							System.out.print(this.minCost[this.ID][i] + ", ");
						
					}
					System.out.print("]\n");
					
				}
				catch(IOException e)
				{
					e.printStackTrace();
				}
				//Reset the timer
				this.timer = new Timer(true);
				this.timer.schedule(new TimeoutHandler(this), this.timeOut);
			}
		}

		
	}

	/**
	 * This method is invoked whenever a timeout occurs
	 * It send the routers DV to all neighbors
	 */
	public synchronized void processTimeout() 
	{
		//Cancel the timer
		this.timer.cancel();
		try
		{
			//Send minCost vector to neighbors
			this.sendAll(this.minCost[this.ID].clone());

			//Printout message to console
			System.out.print("TIMEOUT: Sending DV to neighbors: " + "[");
			for(int i = 0; i < this.minCost[this.ID].length; i++)
			{
				if(i == this.minCost[this.ID].length - 1)
					System.out.print(this.minCost[this.ID][i]);
				else
					System.out.print(this.minCost[this.ID][i] + ", ");	
			}
			System.out.print("]\n");
			
			//Reset timer
			this.timer = new Timer(true);
			this.timer.schedule(new TimeoutHandler(this), this.timeOut);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

	
	/**
	 * A simple test driver
	 * 
	 */
	public static void main(String[] args) {
		// default parameters
		int routerId = 2;
		String serverName = "localhost";
		int serverPort = 2227;
		int updateInterval = 2000; //milli-seconds

		if (args.length == 4) {
			routerId = Integer.parseInt(args[0]);
			serverName = args[1];
			serverPort = Integer.parseInt(args[2]);
			updateInterval = Integer.parseInt(args[3]);
		} else {
			System.out.println("incorrect usage, try again.");
			System.exit(0);
		}
		
		// print the parameters
		System.out.printf("starting Router #%d with parameters:\n", routerId);
		System.out.printf("Relay server host name: %s\n", serverName);
		System.out.printf("Relay server port number: %d\n", serverPort);
		System.out.printf("Routing update intwerval: %d (milli-seconds)\n", updateInterval);

		// start the router
		// the start() method blocks until the router receives a QUIT message
		Router router = new Router(routerId, serverName, serverPort, updateInterval);
		RtnTable rtn = router.start();
		System.out.println("Router terminated normally");

		// print the computed routing table
		System.out.println();
		System.out.println("Routing Table at Router #" + routerId);
		System.out.print(rtn.toString());
	}
}

