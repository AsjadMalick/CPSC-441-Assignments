

/**
 * CPSC 441 A4
 * @author asjad.malick
 * This class will handle timeouts
 */
import java.util.TimerTask;
public class TimeoutHandler extends TimerTask 
{
	//The router running this handler
	Router client;
	
	/**
	 * The constructor for the class
	 * @param r - The Router that generates the timer
	 */
	public TimeoutHandler(Router r)
	{
		client = r;
	}
	@Override
	public void run() 
	{
		//Call the timeout method in the client
		client.processTimeout();
	}
}

